// Adagraph.cpp : Defines the entry point for the dll application.
//

#include "stdafx.h"

/* ---------------------------------------------------------------------
 *
 *  File:        adagraph.cpp
 *  Description: basic Win32 graphics DLL
 *  Rev:         0.5d
 *  Date:        23-jan-1999
 *  Author:      Jerry van Dijk
 *  Mail:        jdijk@acm.org
 *
 *  Copyright (c) Jerry van Dijk, 1997, 1998, 1999
 *  Billie Hollidaystraat 28
 *  2324 LK Leiden
 *  THE NETHERLANDS
 *  tel int +31 (0)71 531 4365
 *
 *  Permission granted to use for any purpose, provided this copyright
 *  remains attached and unmodified.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 *  IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 *  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * ------------------------------------------------------------------ *
 *  Rev:         0.81
 *  Date:        4  March 2005
 *  Author:      Ian Foley, Swinburne University of Technology, Melbourne, Australia
 *
 *  This revision has substantial modifications to enable it to work with
 *  faster machines and machines with larger standard font sizes. The primary
 *  problem occurred with data conflicts in the in-memory screen associated
 *  with the device context from the calling thread and the GraphWin thread.
 *
 *  The problem is not totally resolved, but the fatal error rate is about 1 per 20
 *  executions. Another 1 in 20 error occurs with the BitBlt transfer in the
 *  Windows procedure, but it is not fatal. It is believed that these are also
 *  associated with the data sharing of the in-memory screen. The problem is more
 *  likely to occur when modifications to a larger screen area occur.
 *
 *  Its possible that the robustness of keyboard input has been improved by
 *  making set key_available to true as the last of the key board assignments
 *  in WM_KEYDOWN and WM_CHAR.
 *
 *  Error reporting is more comprehensive and explicit
 * 
 *  DrawLineEx and DrawArc functions have been added. These both have line thickness
 *  parameters
 *
 *  It also contains an earlier fix because the screen coordinates were
 *  incorrectly defined.
 *
 * ------------------------------------------------------------------ */

#include <windows.h>

#ifdef __GNUC__
#define EXPORT
#define CLR_INVALID 0xFFFFFFFF   /* missing in action */
#else
#define EXPORT __declspec(dllexport)
#endif


/**********************************************************************/
/*                            CONSTANTS                               */
/**********************************************************************/

#define DLL_VERSION    81
#define VERSION_STRING "v0.81"
#define ERROR_TITLE    "AdaGraph v0.81 Internal Error"

#define MAX_COLORS 16

#define NORMAL_KEY   0
#define VIRTUAL_KEY  1

#define DEFAULT_WINDOW   0
#define MAXIMIZED_WINDOW 1
#define SIZED_WINDOW     2

#define NONE       0
#define MOVE       1
#define LEFT_UP    2
#define RIGHT_UP   3
#define LEFT_DOWN  4
#define RIGHT_DOWN 5

#define WM_ADAGRAPH_QUIT WM_USER+999

#define CLASS_NAME "ADAGRAPH_CLASS"

#define NO_ERRORS               0
#define WINDOW_ALREADY_OPEN    -1
#define WINDOW_ALREADY_CLOSED  -2
#define CREATE_EVENT_FAILED    -3
#define CREATE_THREAD_FAILED   -4
#define WINDOW_NOT_OPEN        -5
#define INVALID_COLOR_VALUE    -6
#define INVALID_COORDINATE     -7
#define ERROR_COPYING_TITLE    -8
#define ERROR_COPYING_CMDLINE  -9
#define WAIT_FAILED_ERROR     -10
#define SET_TITLE_ERROR       -11
#define FILL_RECT_ERROR       -12
#define INVALIDATE_RECT_ERROR -13
#define UPDATE_WINDOW_ERROR   -14
#define SET_PIXEL_ERROR       -15
#define SELECT_PEN_ERROR      -16
#define MOVE_TO_ERROR         -17
#define LINE_TO_ERROR         -18
#define SELECT_BRUSH_ERROR    -19
#define RECTANGLE_ERROR       -20
#define ELLIPSE_ERROR         -21
#define GET_PIXEL_ERROR       -22
#define FLOOD_FILL_ERROR      -23
#define SET_TEXTCOLOR_ERROR   -24
#define TEXT_OUT_ERROR        -25
#define INVALID_WINDOW_SIZE   -26
#define GET_POSITION_ERROR    -27
#define CLOSE_HANDLE_FAILED   -28
#define THREAD_STATUS_ERROR   -29
#define ARC_ERROR             -30 

#define SIMPLE_BLEEP 0xFFFFFFFF

#define MAX_BITMAPS 32


/**********************************************************************/
/*                              TYPES                                 */
/**********************************************************************/

typedef struct {
   int event;
   int x;
   int y;
} MOUSE_STRUCT;


/**********************************************************************/
/*                        PROCESS GLOBAL DATA                         */
/**********************************************************************/

static int x_size = 0;
static int y_size = 0;

static int x_font = 0;
static int y_font = 0;

static int x_asked = 0;
static int y_asked = 0;

static BOOL active  = FALSE;

static const COLORREF standard_color[MAX_COLORS] = {
   RGB(  0,   0,   0),    /* Black         */
   RGB(  0,   0, 128),    /* Blue          */
   RGB(  0, 128,   0),    /* Green         */
   RGB(  0, 128, 128),    /* Cyan          */
   RGB(128,   0,   0),    /* Red           */
   RGB(128,   0, 128),    /* Magenta       */
   RGB(128, 128,   0),    /* Brown         */
   RGB(172, 172, 172),    /* Light_Gray    */
   RGB( 79,  79,  79),    /* Dark_Gray     */
   RGB(  0,   0, 255),    /* Light_Blue    */
   RGB(  0, 255,   0),    /* Light_Green   */
   RGB(  0, 255, 255),    /* Light_Cyan    */
   RGB(255,   0,   0),    /* Light_Red     */
   RGB(255,   0, 255),    /* Light_Magenta */
   RGB(255, 255,   0),    /* Yellow        */
   RGB(255, 255, 255)     /* White         */
};

static char title[256];

static DWORD  threadID;
static HANDLE hRunning;
static HWND   threadHandle;

static MOUSE_STRUCT mouse = {0, 0, 0};

static HDC     my_dc;
static HWND    my_hwnd;
static RECT    draw_rect, my_rect;
static HBITMAP my_bitmap, old_bitmap;
static LONG iSem = 0;

static HBRUSH   null_brush;
static COLORREF rgb_color[MAX_COLORS];
static HPEN     standard_pen[MAX_COLORS];
static HBRUSH   standard_brush[MAX_COLORS];

static int key_code       = 0;
static BOOL key_stacked   = FALSE;
static BOOL key_available = FALSE;
static int key_type       = NORMAL_KEY;

/**********************************************************************/
/*                       FUNCTION PROTOTYPES                          */
/**********************************************************************/

LONG GraphWin(LPVOID param);
void error_message(int line,char *message);
void size_message(char *msg,int x,int y);
BOOL WINAPI DllMain(HINSTANCE hInst, ULONG reason, LPVOID reserved);
LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);


/**********************************************************************/
/*                        DLL ENTRY POINT                             */
/**********************************************************************/

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG reason, LPVOID reserved)
{
   switch (reason) {

      case DLL_PROCESS_ATTACH:
         x_asked       = 0;
         y_asked       = 0;
         key_code      = 0;
         mouse.event   = 0;
         mouse.x       = 0;
         mouse.y       = 0;
         key_stacked   = FALSE;
         key_available = FALSE;
         key_type      = NORMAL_KEY;
         break;

      case DLL_THREAD_ATTACH:
         break;

      case DLL_THREAD_DETACH:
         break;

      case DLL_PROCESS_DETACH:
         break;
   }

   return TRUE;
}


/**********************************************************************/
/*                        ADA ENTRY POINTS                            */
/**********************************************************************/

/* ------------------------------------------------------------------ */
EXPORT int GetDLLVersion(void)
{
   return DLL_VERSION;
}


/* ------------------------------------------------------------------ */
EXPORT int IsOpen(void)
{
   if (active == TRUE) {
      return 1;
   }
   return 0;
}


/* ------------------------------------------------------------------ */
EXPORT int GetMaxSize(int *x, int *y)
{
   *x = GetSystemMetrics(SM_CXMAXIMIZED) -
        2 * GetSystemMetrics(SM_CXFIXEDFRAME);
   *y = GetSystemMetrics(SM_CYMAXIMIZED) -
        2 * GetSystemMetrics(SM_CYFIXEDFRAME) -
        GetSystemMetrics(SM_CYCAPTION);

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int CreateSizedGraphWindow(int x, int y)
{
   int xmax, ymax;
   int window_size;
   static HANDLE hWait = NULL;

   if (active == TRUE) {
     error_message(__LINE__-1,"CreateSizedGraphWindow - Window already open");
     return WINDOW_ALREADY_OPEN;
   }

   (void)GetMaxSize (&xmax, &ymax);

   if ( (x < 0) || (y < 0) || (x > xmax) || (y > ymax)) {
     error_message(__LINE__-1,"CreateSizedGraphWindow - Invalid Window Size");
      return INVALID_WINDOW_SIZE;
   }

   window_size = SIZED_WINDOW;

   x_asked = x;
   y_asked = y;

   if (lstrcpy(title, "AdaGraph "VERSION_STRING" window for ") == NULL) {
     error_message(__LINE__-1,"CreateSizedGraphWindow - Copy Title Error");
      return ERROR_COPYING_TITLE;
   }

   if (lstrcat(title, GetCommandLine()) == NULL) {
     error_message(__LINE__-1,"CreateSizedGraphWindow - Copy Command Line Error");
      return ERROR_COPYING_CMDLINE;
   }

   hRunning = CreateEvent(NULL, FALSE, FALSE, NULL);
   if (hRunning == NULL) {
     error_message(__LINE__-1,"CreateSizedGraphWindow - Create hRunning Event Failed");
      return CREATE_EVENT_FAILED;
   }

   threadHandle = CreateThread(NULL,
                               0,
                               (LPTHREAD_START_ROUTINE)GraphWin,
                               (LPVOID)&window_size,
                               0,
                               &threadID);
   if (threadHandle == NULL) {
     error_message(__LINE__-1,"CreateSizedGraphWindow - Create Thread Failed");
      return CREATE_THREAD_FAILED;
   }

   if (WaitForSingleObject(hRunning, INFINITE) == WAIT_FAILED) {
     error_message(__LINE__-1,"CreateSizedGraphWindow - Wait Failed");
      return WAIT_FAILED_ERROR;
   }

   if (CloseHandle(hRunning) == FALSE) {
     error_message(__LINE__-1,"CreateSizedGraphWindow - Close Handle Failed");
      return CLOSE_HANDLE_FAILED;
   }

   active  = TRUE;

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int CreateGraphWindow(int size)
{
   int window_size;

   if (active == TRUE) {
     error_message(__LINE__-1,"CreateGraphWindow - Window Already Open");
      return WINDOW_ALREADY_OPEN;
   }

   if ( (size != DEFAULT_WINDOW) && (size != MAXIMIZED_WINDOW) ) {
     error_message(__LINE__-1,"CreateGraphWindow - Invalid Window Size");
      return INVALID_WINDOW_SIZE;
   }

   if (lstrcpy(title, "AdaGraph "VERSION_STRING" window for ") == NULL) {
     error_message(__LINE__-1,"CreateGraphWindow - Copy Title Error");
      return ERROR_COPYING_TITLE;
   }

   if (lstrcat(title, GetCommandLine()) == NULL) {
     error_message(__LINE__-1,"CreateGraphWindow - Copy Command Line Error");
      return ERROR_COPYING_CMDLINE;
   }

   hRunning = CreateEvent(NULL, FALSE, FALSE, NULL);
   if (hRunning == NULL) {
     error_message(__LINE__-1,"CreateGraphWindow - Create Event Failed");
      return CREATE_EVENT_FAILED;
   }

   window_size = size;

   threadHandle = CreateThread(NULL,
                               0,
                               (LPTHREAD_START_ROUTINE)GraphWin,
                               (LPVOID)&window_size,
                               0,
                               &threadID);
   if (threadHandle == NULL) {
     error_message(__LINE__-1,"CreateGraphWindow - Create Thread Failed");
      return CREATE_THREAD_FAILED;
   }

   if (WaitForSingleObject(hRunning, INFINITE) == WAIT_FAILED) {
     error_message(__LINE__-1,"CreateGraphWindow - Wait Failed");
      return WAIT_FAILED_ERROR;
   }

   if (CloseHandle(hRunning) == FALSE) {
     error_message(__LINE__-1,"CreateGraphWindow - Close Handle Failed");
      return CLOSE_HANDLE_FAILED;
   }

   active  = TRUE;

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DestroyGraphWindow(void)
{
   int thread_active;

   if (active == FALSE) {
     error_message(__LINE__-1,"DestroyGraphWindow - Window already closed");
      return WINDOW_ALREADY_CLOSED;
   }

   (void)SendMessage(my_hwnd, WM_ADAGRAPH_QUIT, 0, 0);

   do {
      if (GetExitCodeThread(threadHandle, &thread_active) == FALSE) {
     error_message(__LINE__-1,"DestroyGraphWindow - Thread Status Error");
         return THREAD_STATUS_ERROR;
      }
   } while (thread_active == STILL_ACTIVE);

   if (CloseHandle(threadHandle) == FALSE) {
     error_message(__LINE__-1,"DestroyGraphWindow - Close Handle Failed");
      return CLOSE_HANDLE_FAILED;
   }

   active  = FALSE;

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int GetWindowWidth(void)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"GetWindowWidth - Window not open");
      return WINDOW_NOT_OPEN;
   }

   return x_size;
}


/* ------------------------------------------------------------------ */
EXPORT int GetWindowHeight(void)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"GetWindowHeight - Window not open");
      return WINDOW_NOT_OPEN;
   }

   return y_size;
}


/* ------------------------------------------------------------------ */
EXPORT int GetFontWidth(void)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"GetFontWidth - Window not open");
      return WINDOW_NOT_OPEN;
   }

   return x_font;
}


/* ------------------------------------------------------------------ */
EXPORT int GetFontHeight(void)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"GetFontHeight - Window not open");
       return WINDOW_NOT_OPEN;
   }

   return y_font;
}


/* ------------------------------------------------------------------ */
EXPORT int ClearWindow(int color_index)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"ClearWindow - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"ClearWindow - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

  if (FillRect(my_dc, &my_rect, standard_brush[color_index]) == FALSE) {
     error_message(__LINE__-1,"ClearWindow - Fill Rectangle Error");
      return FILL_RECT_ERROR;
   }

   if (InvalidateRect(my_hwnd, NULL, TRUE) == FALSE) {
     error_message(__LINE__-1,"ClearWindow - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"ClearWindow - UpdateWindow Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int SetWindowTitle(char *title)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"SetWindowTitle - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if (SetWindowText(my_hwnd, title) == FALSE) {
     error_message(__LINE__-1,"SetWindowTitle - Set Title Error");
      return SET_TITLE_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int GetColorPixel(int x, int y)
{
   int i;
   COLORREF pixel_color;

   if (active == FALSE) {
     error_message(__LINE__-1,"GetColorPixel - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      size_message("GetColorPixel",x,y);
      return INVALID_COORDINATE;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   pixel_color = GetPixel(my_dc, x, y);
   if (pixel_color == CLR_INVALID) {
     error_message(__LINE__-1,"GetColorPixel - Get Pixel Error");
      return GET_PIXEL_ERROR;
   }

   for (i = 0; i < MAX_COLORS; i++) {
      if (rgb_color[i] == pixel_color) {
         return i;
      }
   }

   error_message(__LINE__-1,"GetColorPixel - Invalid Color Value");
   return INVALID_COLOR_VALUE;
}


/* ------------------------------------------------------------------ */
EXPORT int PutPixel(int x, int y, int color_index)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"PutPixel - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"PutPixel - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      size_message("PutPixel",x,y);
      return INVALID_COORDINATE;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   if (SetPixelV(my_dc, x, y, rgb_color[color_index]) == FALSE) {
     error_message(__LINE__-1,"PutPixel - Set Pixel Error");
      return SET_PIXEL_ERROR;
   }

   draw_rect.left   = x;
   draw_rect.right  = x + 1;
   draw_rect.top    = y;
   draw_rect.bottom = y + 1;

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
     error_message(__LINE__-1,"PutPixel - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"PutPixel - UpdateWindow");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DrawLine(int x1, int y1, int x2, int y2, int color_index)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"DrawLine - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"DrawLine - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x1 < 0) || (y1 < 0) || (x1 > x_size) || (y1 > y_size) ) {
      size_message("DrawLine",x1,y1);
      return INVALID_COORDINATE;
   }

   if ( (x2 < 0) || (y2 < 0) || (x2 > x_size) || (y2 > y_size) ) {
      size_message("DrawLine",x2,y2);
      return INVALID_COORDINATE;
   }

   if ( (x1 == x2) && (y1 == y2) ) {
      return PutPixel(x1, y1, color_index);
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawLine - Select Pen Error");
      return SELECT_PEN_ERROR;
   }

   if (MoveToEx(my_dc, x1, y1, NULL) == FALSE) {
     error_message(__LINE__-1,"DrawLine - MoveTo Error");
      return MOVE_TO_ERROR;
   }

   if (LineTo(my_dc, x2, y2) == FALSE) {
     error_message(__LINE__-1,"DrawLine - LineTo Error");
      return LINE_TO_ERROR;
   }

   if (SetPixelV(my_dc, x2, y2, rgb_color[color_index]) == FALSE) {
     error_message(__LINE__-1,"DrawLine - Set Pixel Error");
      return SET_PIXEL_ERROR;
   }

   if (x2 >= x1) {
      draw_rect.left  = x1;
      draw_rect.right = x2 + 1;
   }
   else {
      draw_rect.left  = x2;
      draw_rect.right = x1 + 1;
   }

   if (y2 >= y1) {
      draw_rect.top    = y1;
      draw_rect.bottom = y2 + 1;
   }
   else {
      draw_rect.top    = y2;
      draw_rect.bottom = y1 + 1;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
     error_message(__LINE__-1,"DrawLine - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"DrawLine - UpdateWindow Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}

/* ------------------------------------------------------------------ */
EXPORT int DrawLineEx(int x1, int y1, int x2, int y2, int color_index, int nWidth)
{
  HPEN hPen;

   if (active == FALSE) {
     error_message(__LINE__-1,"DrawLine - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"DrawLine - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x1 < 0) || (y1 < 0) || (x1 > x_size) || (y1 > y_size) ) {
      size_message("DrawLine",x1,y1);
      return INVALID_COORDINATE;
   }

   if ( (x2 < 0) || (y2 < 0) || (x2 > x_size) || (y2 > y_size) ) {
      size_message("DrawLine",x2,y2);
      return INVALID_COORDINATE;
   }

   if ( (x1 == x2) && (y1 == y2) ) {
      return PutPixel(x1, y1, color_index);
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   hPen = CreatePen(PS_SOLID, nWidth, color_index);
   if (hPen == NULL) 
   { 
     error_message(__LINE__-1,"DrawLineEx - Create Pen Failed");
   }

   if (SelectObject(my_dc, hPen) == NULL) {
     error_message(__LINE__-1,"DrawLineEx - Select Pen Error");
      return SELECT_PEN_ERROR;
   }

   if (MoveToEx(my_dc, x1, y1, NULL) == FALSE) {
     error_message(__LINE__-1,"DrawLineEx - MoveTo Error");
      return MOVE_TO_ERROR;
   }

   if (LineTo(my_dc, x2, y2) == FALSE) {
     error_message(__LINE__-1,"DrawLineEx - LineTo Error");
      return LINE_TO_ERROR;
   }

   if (SetPixelV(my_dc, x2, y2, rgb_color[color_index]) == FALSE) {
     error_message(__LINE__-1,"DrawLineEx - Set Pixel Error");
      return SET_PIXEL_ERROR;
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawLineEx - Select Pen Error");
      return SELECT_PEN_ERROR;
   }

   if (DeleteObject(hPen) == FALSE) {
     error_message(__LINE__-1,"DrawLineEx - Delete Pen Failed");
      return SELECT_PEN_ERROR;
   }

   if (x2 >= x1) {
      draw_rect.left  = x1;
      draw_rect.right = x2 + 1;
   }
   else {
      draw_rect.left  = x2;
      draw_rect.right = x1 + 1;
   }

   if (y2 >= y1) {
      draw_rect.top    = y1;
      draw_rect.bottom = y2 + 1;
   }
   else {
      draw_rect.top    = y2;
      draw_rect.bottom = y1 + 1;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
     error_message(__LINE__-1,"DrawLineEx - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"DrawLineEx - UpdateWindow Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}

/* ------------------------------------------------------------------ */
EXPORT int DrawBox(int x1, int y1, int x2, int y2, int color_index, int filled)
{
   int d_x1, d_x2, d_y1, d_y2;

   if (active == FALSE) {
     error_message(__LINE__-1,"DrawBox - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"DrawBox - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x1 < 0) || (y1 < 0) || (x1 > x_size) || (y1 > y_size) ) {
      size_message("DrawBox",x1,y1);
      return INVALID_COORDINATE;
   }

   if ( (x2 < 0) || (y2 < 0) || (x2 > x_size) || (y2 > y_size) ) {
      size_message("DrawBox",x2,y2);
      return INVALID_COORDINATE;
   }

   if ((x1 == x2) && (y1 == y2)) {
      return PutPixel(x1, y1, color_index);
   }

   if ((x1 == x2) || (y1 == y2)) {
      return DrawLine(x1, y1, x2, y2, color_index);
   }

   if (x2 > x1) {
      d_x1 = x1;
      d_x2 = x2;
   }
   else {
      d_x1 = x2;
      d_x2 = x1;
   }

   if (y2 > y1) {
        d_y1 = y1;
        d_y2 = y2;
   }
   else {
      d_y1 = y2;
      d_y2 = y1;
   }

   d_x2++;
   d_y2++;

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   if (filled == TRUE) {
      if (SelectObject(my_dc, standard_brush[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawBox - Select Standard Brush Error");
         return SELECT_BRUSH_ERROR;
      }
   }
   else {
      if (SelectObject(my_dc, null_brush) == NULL) {
     error_message(__LINE__-1,"DrawBox - Select Null Brush Error");
         return SELECT_BRUSH_ERROR;
       }
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawBox - Select Pen Error");
      return SELECT_PEN_ERROR;
   }

   if (Rectangle(my_dc, d_x1, d_y1, d_x2, d_y2) == FALSE) {
     error_message(__LINE__-1,"DrawBox - Rectangle Error");
      return RECTANGLE_ERROR;
   }

   draw_rect.left   = d_x1;
   draw_rect.right  = d_x2;
   draw_rect.top    = d_y1;
   draw_rect.bottom = d_y2;

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
     error_message(__LINE__-1,"DrawBox - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"DrawBox - UpdateWindow Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DrawCircle(int x, int y, int radius, int color_index, int filled)
{
   int d_x1, d_x2, d_y1, d_y2;

   if (active == FALSE) {
     error_message(__LINE__-1,"DrawCircle - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"DrawCircle - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      size_message("DrawCircle",x,y);
      return INVALID_COORDINATE;
   }

   if (radius == 0) {
      return PutPixel(x, y, color_index);
   }

   if ( ((x - radius) < 0) || ((y - radius) < 0) ||
        ((x + radius) > x_size) || ((y + radius) > y_size) ) {
      size_message("DrawCircle - radius",x-radius,y-radius);
      size_message("DrawCircle + radius",x+radius,y+radius);
      return INVALID_COORDINATE;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   draw_rect.left   = d_x1 = x - radius;
   draw_rect.top    = d_y1 = y - radius;
   draw_rect.right  = d_x2 = x + radius + 1;
   draw_rect.bottom = d_y2 = y + radius + 1;

   if (filled == TRUE) {
      if (SelectObject(my_dc, standard_brush[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawCircle - Select Standard Brush Error");
         return SELECT_BRUSH_ERROR;
      }
   }
   else {
      if (SelectObject(my_dc, null_brush) == NULL) {
     error_message(__LINE__-1,"DrawCircle - Select Null Brush Error");
         return SELECT_BRUSH_ERROR;
       }
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawCircle - Select Pen Error");
      return SELECT_PEN_ERROR;
   }

   if (Ellipse(my_dc, d_x1, d_y1, d_x2, d_y2) == FALSE) {
     error_message(__LINE__-1,"DrawCircle - Ellipse Error");
      return ELLIPSE_ERROR;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
     error_message(__LINE__-1,"DrawCircle - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"DrawCircle - Update Window Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DrawEllipse(int x1, int y1, int x2, int y2, int color_index, int filled)
{
   int d_x1, d_x2, d_y1, d_y2;

   if (active == FALSE) {
     error_message(__LINE__-1,"DrawEllipse - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"DrawEllispe - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x1 < 0) || (y1 < 0) || (x1 > x_size) || (y1 > y_size) ) {
      size_message("DrawEllipse",x1,y1);
      return INVALID_COORDINATE;
   }

   if ( (x2 < 0) || (y2 < 0) || (x2 > x_size) || (y2 > y_size) ) {
      size_message("DrawEllispe",x2,y2);
      return INVALID_COORDINATE;
   }

   if ((x1 == x2) && (y1 == y2)) {
      return PutPixel(x1, y1, color_index);
   }

   if ((x1 == x2) || (y1 == y2)) {
      return DrawLine(x1, x2, y1, y2, color_index);
   }

   if (x2 > x1) {
      d_x1 = x1;
      d_x2 = x2;
   }
   else {
      d_x1 = x2;
      d_x2 = x1;
   }

   if (y2 > y1) {
      d_y1 = y1;
      d_y2 = y2;
   }
   else {
      d_y1 = y2;
      d_y2 = y1;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   draw_rect.left   = d_x1;
   draw_rect.right  = d_x2 + 1;
   draw_rect.top    = d_y1;
   draw_rect.bottom = d_y2 + 1;

   if (filled == TRUE) {
      if (SelectObject(my_dc, standard_brush[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawEllipse - Select Standard Brush Error");
         return SELECT_BRUSH_ERROR;
      }
   }
   else {
      if (SelectObject(my_dc, null_brush) == NULL) {
     error_message(__LINE__-1,"DrawEllipse - Select Null Brush error");
         return SELECT_BRUSH_ERROR;
      }
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawEllipse - Select Pen error");
      return SELECT_PEN_ERROR;
   }

   if (Ellipse(my_dc, d_x1, d_y1, d_x2, d_y2) == FALSE) {
     error_message(__LINE__-1,"DrawEllipse - Ellipse Error");
      return ELLIPSE_ERROR;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
     error_message(__LINE__-1,"DrawEllipse - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"DrawEllipse - Update Window Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}

/* ------------------------------------------------------------------ */
  // x1 rectangle's upper-left corner
  // y1 rectangle's upper-left corner
  // x2 rectangle's lower-right corner
  // y2 rectangle's lower-right corner
  // color_index is color of line
  // nWidth is thickness of line in pixels
  // x1a first radial ending point
  // y1a first radial ending point
  // x2a second radial ending point
  // y2a second radial ending point
EXPORT int DrawArc(int x1, int y1, int x2, int y2, int color_index, int nWidth,
                   int x1a, int y1a, int x2a, int y2a)
{
  HPEN hPen;

   if (active == FALSE) {
     error_message(__LINE__-1,"DrawArc - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"DrawArc - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x1 < 0) || (y1 < 0) || (x1 > x_size) || (y1 > y_size) ) {
      size_message("DrawArc",x1,y1);
      return INVALID_COORDINATE;
   }

   if ( (x2 < 0) || (y2 < 0) || (x2 > x_size) || (y2 > y_size) ) {
      size_message("DrawArc",x2,y2);
      return INVALID_COORDINATE;
   }

   if ( (x1a < 0) || (y1a < 0) || (x1a > x_size) || (y1a > y_size) ) {
      size_message("DrawArc",x1a,y1a);
      return INVALID_COORDINATE;
   }

   if ( (x2a < 0) || (y2a < 0) || (x2a > x_size) || (y2a > y_size) ) {
      size_message("DrawArc",x2,y2);
      return INVALID_COORDINATE;
   }

   if ( (x1 == x2) && (y1 == y2) ) {
      return PutPixel(x1, y1, color_index);
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   hPen = CreatePen(PS_SOLID, nWidth, color_index);
   if (hPen == NULL) 
   { 
     error_message(__LINE__-1,"DrawArc - Create Pen Failed");
   }

   if (SelectObject(my_dc, hPen) == NULL) {
     error_message(__LINE__-1,"DrawArc - Select Pen Error");
      return SELECT_PEN_ERROR;
   }

   if (Arc(my_dc, x1, y1, x2, y2, x1a, y1a, x2a, y2a) == FALSE) {
     error_message(__LINE__-1,"DrawArc - Arc Error");
      return ARC_ERROR;
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawArc - Select Pen Error");
      return SELECT_PEN_ERROR;
   }

   if (DeleteObject(hPen) == FALSE) {
     error_message(__LINE__-1,"DrawArc - Delete Pen Failed");
      return SELECT_PEN_ERROR;
   }

   if (x2 >= x1) {
      draw_rect.left  = x1;
      draw_rect.right = x2 + 1;
   }
   else {
      draw_rect.left  = x2;
      draw_rect.right = x1 + 1;
   }

   if (y2 >= y1) {
      draw_rect.top    = y1;
      draw_rect.bottom = y2 + 1;
   }
   else {
      draw_rect.top    = y2;
      draw_rect.bottom = y1 + 1;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
     error_message(__LINE__-1,"DrawArc - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"DrawArc - UpdateWindow Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}

/* ------------------------------------------------------------------ */
EXPORT int FillFlood(int x, int y, int color_index)
{
   COLORREF color;

   if (active == FALSE) {
     error_message(__LINE__-1,"FillFlood - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"FillFlood - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      size_message("FillFlood",x,y);
      return INVALID_COORDINATE;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   color = GetPixel(my_dc, x, y);
   if (color == CLR_INVALID) {
     error_message(__LINE__-1,"FillFlood - Get Pixel Error");
      return GET_PIXEL_ERROR;
   }

   if (SelectObject(my_dc, standard_brush[color_index]) == NULL) {
     error_message(__LINE__-1,"FillFlood - Select Standard Brush Error");
      return SELECT_BRUSH_ERROR;
   }

   if (ExtFloodFill(my_dc, x, y, color, FLOODFILLSURFACE) == FALSE) {
     error_message(__LINE__-1,"FillFlood - Flood Fill Error");
      return FLOOD_FILL_ERROR;
   }

   if (InvalidateRect(my_hwnd, NULL, FALSE) == FALSE) {
     error_message(__LINE__-1,"FillFlood - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"FillFlood - Update Window Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DisplayText(int x, int y, char *text, int color_index)
{
   int str_length, x_end, y_end;
   RECT draw_rect;

   if (active == FALSE) {
     error_message(__LINE__-1,"DisplayText - Window not open");
      return WINDOW_NOT_OPEN;
   }

   str_length = lstrlen(text);

   if (str_length == 0) {
      return NO_ERRORS;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"DisplayText - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      size_message("DisplayText",x,y);
      return INVALID_COORDINATE;
   }

   x_end = x + str_length * x_font - 1;

   if ( x_end > x_size) {
      size_message("DisplayText x_end and x_size",x_end,x_size);
      return INVALID_COORDINATE;
   }

   y_end = y + y_font - 1;

   if ( y_end > y_size) {
      size_message("DisplayText y_end and y_size",y_end,y_size);
      return INVALID_COORDINATE;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   if (SetTextColor(my_dc, rgb_color[color_index]) == CLR_INVALID) {
     error_message(__LINE__-1,"DisplayText - Set Text Color Error");
      return SET_TEXTCOLOR_ERROR;
   }

   if (TextOut(my_dc, x, y, text, str_length) == FALSE) {
     error_message(__LINE__-1,"DisplayText - TextOut Error");
      return TEXT_OUT_ERROR;
   }

   draw_rect.left   = x;
   draw_rect.right  = x_end + 1;
   draw_rect.top    = y;
   draw_rect.bottom = y_end + 1;

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
     error_message(__LINE__-1,"DisplayText - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"DisplayText - UpdateWindow Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int WhereX(void)
{
   POINT my_point;

   if (active == FALSE) {
     error_message(__LINE__-1,"WhereX - Window not open");
      return WINDOW_NOT_OPEN;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   if (GetCurrentPositionEx(my_dc, &my_point) == FALSE) {
     error_message(__LINE__-1,"WhereX - Get Position Error");
      return GET_POSITION_ERROR;
   }

   return (int)my_point.x;
}


/* ------------------------------------------------------------------ */
EXPORT int WhereY(void)
{
   POINT my_point;

   if (active == FALSE) {
     error_message(__LINE__-1,"WhereY - Window not open");
      return WINDOW_NOT_OPEN;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   if (GetCurrentPositionEx(my_dc, &my_point) == FALSE) {
     error_message(__LINE__-1,"WhereY - Get Position Error");
      return GET_POSITION_ERROR;
   }

   return (int)my_point.y;
}


/* ------------------------------------------------------------------ */
EXPORT int GotoXY(int x, int y)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"GotoXY - Window not open");
      return WINDOW_NOT_OPEN;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   if (MoveToEx(my_dc, x, y, NULL) == FALSE) {
     error_message(__LINE__-1,"GotoXY - Move To Error");
      return MOVE_TO_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DrawTo(int x, int y, int color_index)
{
   POINT my_point;
   int curr_x, curr_y;

   if (active == FALSE) {
     error_message(__LINE__-1,"DrawTo - Window not open");
      return WINDOW_NOT_OPEN;
   }

   while (iSem >= 1L)
   {
     Sleep(1);
   }
   InterlockedExchangeAdd(&iSem,1L);

   if (GetCurrentPositionEx(my_dc, &my_point) == FALSE) {
     error_message(__LINE__-1,"DrawTo - Get Position Error");
      return GET_POSITION_ERROR;
   }
   curr_x = (int)my_point.x;
   curr_y = (int)my_point.y;

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
     error_message(__LINE__-1,"DrawTo - Invalid Color Value");
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      size_message("DrawTo",x,y);
      return INVALID_COORDINATE;
   }

   if ( (x == curr_x) && (y == curr_y) ) {
      if (iSem >= 1L)
       InterlockedExchangeAdd(&iSem,-1L);
      return PutPixel(x, y, color_index);
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
     error_message(__LINE__-1,"DrawTo - Select pen Error");
      return SELECT_PEN_ERROR;
   }

   if (LineTo(my_dc, x, y) == FALSE) {
     error_message(__LINE__-1,"DrawTo - Line To Error");
      return LINE_TO_ERROR;
   }

   if (SetPixelV(my_dc, x, y, rgb_color[color_index]) == FALSE) {
     error_message(__LINE__-1,"DrawTo - Set Pixel Error");
      return SET_PIXEL_ERROR;
   }

   if (x >= curr_x) {
      draw_rect.left  = curr_x;
      draw_rect.right = x + 1;
   }
   else {
      draw_rect.left  = x;
      draw_rect.right = curr_x + 1;
   }

   if (y >= curr_y) {
      draw_rect.top    = curr_y;
      draw_rect.bottom = y + 1;
   }
   else {
      draw_rect.top    = y;
      draw_rect.bottom = curr_y + 1;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
     error_message(__LINE__-1,"DrawTo - InvalidateRect Error");
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
     error_message(__LINE__-1,"DrawTo - Update Window Error");
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int KeyHit(void)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"KeyHit - Window not open");
      return WINDOW_NOT_OPEN;
   }

   return key_available;
}


/* ------------------------------------------------------------------ */
EXPORT int GetKey(void)
{
   int result;

   if (active == FALSE) {
     error_message(__LINE__-1,"GetKey - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if (key_stacked == TRUE) {
      result = key_code;
      key_stacked = FALSE;
      return result;
   }

   while (key_available == FALSE) {
      /* do_nothing */
   }

   if (key_type == NORMAL_KEY) {
      result = key_code;
   }
   else {
      result = 0;
      key_stacked = TRUE;
   }

   key_available = FALSE;

   return result;
}


/* ------------------------------------------------------------------ */
EXPORT int MouseEvent(void)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"MouseEvent - Window not open");
      return WINDOW_NOT_OPEN;
   }

   if (mouse.event != NONE) {
      return 1;
   }
   else {
      return 0;
   }
}


/* ------------------------------------------------------------------ */
EXPORT int GetMouse(MOUSE_STRUCT *mouse_event)
{
   if (active == FALSE) {
     error_message(__LINE__-1,"GetMouse - Window not open");
      return WINDOW_NOT_OPEN;
   }

   while (mouse.event == NONE) {
      /* do nothing */
   }

   *mouse_event = mouse;
   mouse.event = mouse.x = mouse.y = 0;

   return NO_ERRORS;
}


/**********************************************************************/
/*                    GRAPHICAL WINDOW THREAD                         */
/**********************************************************************/

LONG GraphWin(LPVOID size)
{
   HDC hDC;
   HFONT hFont;
   MSG msg;
   TEXTMETRIC tm;
   WNDCLASS wndclass;
   int i, x1, y1, x2, y2;
   char displayText[80];
   BOOL debug = FALSE;

   wndclass.style         = CS_BYTEALIGNCLIENT | CS_NOCLOSE;
   wndclass.lpfnWndProc   = WndProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = NULL;
   wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
   wndclass.hbrBackground = GetStockObject(BLACK_BRUSH);
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = CLASS_NAME;

   (void) RegisterClass (&wndclass);

   switch (*((int *)size)) {

      case DEFAULT_WINDOW:
         x1 = y1 = x2 = y2 = CW_USEDEFAULT;
         if (debug)
         {
           wsprintf(displayText,"x1,y1,x2,y2 - %u,%u,%u,%u",x1,y1,x2,y2);
           MessageBox(NULL, displayText, "Message", 
             MB_OK | MB_ICONASTERISK );
         }
         break;

      case MAXIMIZED_WINDOW:
         x1 = 0;
         y1 = 0;
         x2 = GetSystemMetrics(SM_CXMAXIMIZED) -
              2 * GetSystemMetrics(SM_CXFIXEDFRAME);
         y2 = GetSystemMetrics(SM_CYMAXIMIZED) -
              2 * GetSystemMetrics(SM_CYFIXEDFRAME);
         break;

      case SIZED_WINDOW:
         x1 = 0;
         y1 = 0;
         x2 = x_asked + 2 * GetSystemMetrics(SM_CXFIXEDFRAME);
         y2 = y_asked + 2 * GetSystemMetrics(SM_CYFIXEDFRAME) +
              GetSystemMetrics(SM_CYCAPTION);
         if (debug)
         {
           wsprintf(displayText,"x1,y1,x2,y2 - %u,%u,%u,%u",x1,y1,x2,y2);
           MessageBox(NULL, displayText, "Message", 
            MB_OK | MB_ICONASTERISK );
         }
         break;

   }

   my_hwnd = CreateWindow(CLASS_NAME,
                          title,
                          WS_OVERLAPPED,
                          x1,
                          y1,
                          x2,
                          y2,
                          NULL,
                          NULL,
                          NULL,
                          NULL);
   if (my_hwnd == NULL) 
    { error_message(__LINE__-1,"GraphWin - CreateWindow Failed"); }

   if (GetClientRect(my_hwnd, &my_rect) == FALSE) 
    { error_message(__LINE__-1,"GraphWin - GetClientRect Failed"); }
   x_size = (int)my_rect.right - 1;
   y_size = (int)my_rect.bottom - 1;
   if (debug)
   {
     wsprintf(displayText,"x_size, y_size - %u,%u",x_size,y_size);
     MessageBox(NULL, displayText, "Message", 
      MB_OK | MB_ICONASTERISK );
   }

     // Need an 8x12 fixed width font
   hFont = CreateFont(12,8,0,0,FW_NORMAL,0,0,0,ANSI_CHARSET,
     OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
     FIXED_PITCH /*| FF_MODERN*/,"Lucida Console");
   if (hFont == 0)
   {
     error_message(__LINE__-1,"GraphWin - Cannot set to Lucida Console"); 
     hFont = CreateFont(12,8,0,0,FW_NORMAL,0,0,0,ANSI_CHARSET,
       OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
       FIXED_PITCH /*| FF_MODERN*/,"8514OEM");
     if (hFont == 0)
     {
       error_message(__LINE__-1,"GraphWin - Cannot set to 8514OEM"); 
       hFont = CreateFont(13,8,0,0,FW_NORMAL,0,0,0,ANSI_CHARSET,
         OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
         FIXED_PITCH /*| FF_MODERN*/,"Courier New");
     }
   }
   hDC = GetDC(my_hwnd);
   if (hDC == NULL) 
    { error_message(__LINE__-1,"GraphWin - GetDC Failed"); }

   my_dc = CreateCompatibleDC(hDC);
   if (my_dc == NULL) 
    { error_message(__LINE__-1,"GraphWin - CreateCompatibleDC Failed"); }

   my_bitmap = CreateCompatibleBitmap(hDC, x_size + 1, y_size + 1);
   if (my_bitmap == NULL) 
    { error_message(__LINE__-1,"GraphWin - CreateCompatibleBitmap Failed"); }

   old_bitmap = SelectObject(my_dc, my_bitmap);
   if (old_bitmap == NULL) 
    { error_message(__LINE__-1,"GraphWin - Failed to select Bitmap into device context"); }

   if (ReleaseDC(my_hwnd, hDC) == 0) 
    { error_message(__LINE__-1,"GraphWin - Release old DC failed"); }

   for (i = 0; i < MAX_COLORS; i++) {
      rgb_color[i] = GetNearestColor(my_dc, standard_color[i]);
      if (rgb_color[i] == CLR_INVALID) 
       { error_message(__LINE__-1,"GraphWin - Invalid Color"); }
      standard_brush[i] = CreateSolidBrush(rgb_color[i]);
      if (standard_brush[i] == NULL) 
       { error_message(__LINE__-1,"GraphWin - Create Brush Failed"); }
      standard_pen[i] = CreatePen(PS_SOLID, 0, rgb_color[i]);
      if (standard_pen[i] == NULL) 
       { error_message(__LINE__-1,"GraphWin - Create Pen Failed"); }
   }

   if (SelectObject (my_dc, hFont) == NULL) {
      error_message(__LINE__-1,"GraphWin - Failed to set font");
   }

   if (GetTextMetrics(my_dc, &tm) == FALSE) 
    { error_message(__LINE__-1,"GraphWin - GetTextMetrics Failed"); }
   x_font = tm.tmMaxCharWidth;
   y_font = tm.tmHeight;
   if (debug)
   {
     wsprintf(displayText,"x_font, y_font - %u,%u",x_font,y_font);
     MessageBox(NULL, displayText, "Message", 
      MB_OK | MB_ICONASTERISK );
   }

   if (SetBkMode(my_dc, TRANSPARENT) == 0) 
    { error_message(__LINE__-1,"GraphWin - Failed to set background mode"); }

   null_brush = GetStockObject(NULL_BRUSH);
   if (null_brush == NULL) 
    { error_message(__LINE__-1,"GraphWin - NUll Brush not null"); }

   if (FillRect(my_dc, &my_rect, standard_brush[0]) == FALSE) {
      error_message(__LINE__-1,"GraphWin - Fill Rect Failed");
   }

   if (GdiSetBatchLimit(1) == 0) 
    { error_message(__LINE__-1,"GraphWin - Failed to set batch limit"); }

   if (SetEvent(hRunning) == FALSE) 
    { error_message(__LINE__-1,"GraphWin - Set hRunning Event failed"); }

   (void)ShowWindow(my_hwnd, SW_SHOWNORMAL);
   if (UpdateWindow(my_hwnd) == FALSE) 
    { error_message(__LINE__-1,"GraphWin - UpdateWindow Failed"); }
   (void)SetForegroundWindow(my_hwnd); /* always fails but is necessary */

   while (GetMessage(&msg, NULL, 0, 0)) {
      (void)TranslateMessage(&msg);
      (void)DispatchMessage(&msg);
   }

   if (DeleteObject(SelectObject(my_dc, old_bitmap)) == FALSE) {
      error_message(__LINE__-1,"GraphWin - Delete bitmap failed");
   }

   if (DeleteDC(my_dc) == FALSE) 
    { error_message(__LINE__-1,"GraphWin - Delete DC Failed"); }

   for (i = 0; i < MAX_COLORS; i++) {
      if (DeleteObject(standard_pen[i]) == FALSE) 
       { error_message(__LINE__-1,"GraphWin - Delete Pen Failed"); }
      if (DeleteObject(standard_brush[i]) == FALSE) 
       { error_message(__LINE__-1,"GraphWin - Delete Brush Failed"); }
   }

   return (LONG)msg.wParam;
}


/**********************************************************************/
/*                  GRAPHICAL WINDOW PROCEDURE                        */
/**********************************************************************/

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (uMsg) {

      case WM_ADAGRAPH_QUIT:
         (void)SendMessage(hwnd, WM_DESTROY, 0, 0);
         return 0;

      case WM_DESTROY:
         (void)PostQuitMessage(NO_ERRORS);
         return 0;

      case WM_PAINT:
         if (BeginPaint(hwnd, &ps) == NULL) 
          { error_message(__LINE__-1,
          "BeginPaint failed"); };

         if (BitBlt(ps.hdc,
                    ps.rcPaint.left,
                    ps.rcPaint.top,
                    ps.rcPaint.right + 1,
                    ps.rcPaint.bottom + 1,
                    my_dc,
                    ps.rcPaint.left,
                    ps.rcPaint.top,
                    SRCCOPY) == FALSE) {
            error_message(__LINE__-1,
              "Bit Block Transfer failed");
         }

         (void)EndPaint(hwnd, &ps);
           // Possible for other than calls to draw methods in calling thread
           // to cause a paint message to be generated. Still possible for thread
           // context switch to occur between the if and the assignment to occur
           // but extremely rare.
         if (iSem >= 1L)
          iSem = 0;
          //InterlockedExchangeAdd(&iSem,-1L);
         return 0;

      case WM_KEYDOWN:
         if (key_available == FALSE) {
            switch (wParam) {
               case VK_PRIOR: /* page-up   */
               case VK_NEXT:  /* page-down */
               case VK_END:
               case VK_HOME:
               case VK_LEFT:
               case VK_UP:
               case VK_RIGHT:
               case VK_DOWN:
               case VK_INSERT:
               case VK_DELETE:
                  key_code      = (int)wParam;
                  key_type      = VIRTUAL_KEY;
                  key_available = TRUE;
                  return 0;
            }
            return 0;
         }
         if (MessageBeep (SIMPLE_BLEEP) == FALSE) 
          { error_message(__LINE__-1,
            "WM_KEYDOWN beep failed"); }
         return 0;    // Was 1. Not sure if an error

      case WM_CHAR:
         if (key_available == FALSE) {
            key_code      = (int)wParam;
            key_type      = NORMAL_KEY;
            key_available = TRUE;
            return 0;
         }
         if (MessageBeep (SIMPLE_BLEEP) == FALSE)
          { error_message(__LINE__-1,
          "WM_CHAR beep failed"); }
         return 0;

      case WM_LBUTTONUP:
         mouse.event = LEFT_UP;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;

      case WM_LBUTTONDOWN:
         mouse.event = LEFT_DOWN;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;

      case WM_RBUTTONUP:
         mouse.event = RIGHT_UP;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;

      case WM_RBUTTONDOWN:
         mouse.event = RIGHT_DOWN;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;

      case WM_MOUSEMOVE:
         mouse.event = MOVE;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;
   }

   return DefWindowProc(hwnd, uMsg, wParam, lParam);
}


/**********************************************************************/
/*                       GRAPHICS ERROR MESSAGE                       */
/**********************************************************************/

void error_message(int line,char *message)
{
   LPVOID msg;
   char error_msg[256];

   (void)FormatMessage(
      FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
      NULL,
      GetLastError(),
      MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
      (LPTSTR) &msg,
      0,
      NULL
   );

   (void)wsprintf(error_msg, "ADAGRAPH.C at line %d\n%s\n%s", line, msg,
     message);

   (void)MessageBeep (SIMPLE_BLEEP);
   (void)MessageBox(NULL,
                    error_msg,
                    ERROR_TITLE,
                    MB_OK |
                    MB_ICONINFORMATION |
                    MB_SYSTEMMODAL |
                    MB_TOPMOST |
                    MB_SETFOREGROUND);

   (void)LocalFree(msg);
}

void size_message(char *msg,int x,int y)
{
   char size_msg[256];

   (void)wsprintf(size_msg, "ADAGRAPH.C msg,x,y %s %d %d\n", msg,x,y);

   (void)MessageBeep (SIMPLE_BLEEP);
   (void)MessageBox(NULL,
                    size_msg,
                    ERROR_TITLE,
                    MB_OK |
                    MB_ICONINFORMATION |
                    MB_SYSTEMMODAL |
                    MB_TOPMOST |
                    MB_SETFOREGROUND);

}
