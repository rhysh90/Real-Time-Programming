/* ---------------------------------------------------------------------
 *
 *  File:        adagraph.c
 *  Description: basic Win32 graphics DLL
 *  Rev:         0.5d
 *  Date:        23-jan-1999
 *  Author:      Jerry van Dijk
 *  Mail:        jdijk@acm.org
 *
 *  Copyright (c) Jerry van Dijk, 1997, 1998, 1999
 *  Billie Hollidaystraat 28
 *  2324 LK Leiden
 *  THE NETHERLANDS
 *  tel int +31 (0)71 531 4365
 *
 *  Permission granted to use for any purpose, provided this copyright
 *  remains attached and unmodified.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 *  IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 *  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * ------------------------------------------------------------------ */

#include <windows.h>

#ifdef __GNUC__
#define EXPORT
#define CLR_INVALID 0xFFFFFFFF   /* missing in action */
#else
#define EXPORT __declspec(dllexport)
#endif


/**********************************************************************/
/*                            CONSTANTS                               */
/**********************************************************************/

#define DLL_VERSION    5
#define VERSION_STRING "v0.5c"
#define ERROR_TITLE    "AdaGraph v0.5c Internal Error"

#define MAX_COLORS 16

#define NORMAL_KEY   0
#define VIRTUAL_KEY  1

#define DEFAULT_WINDOW   0
#define MAXIMIZED_WINDOW 1
#define SIZED_WINDOW     2

#define NONE       0
#define MOVE       1
#define LEFT_UP    2
#define RIGHT_UP   3
#define LEFT_DOWN  4
#define RIGHT_DOWN 5

#define WM_ADAGRAPH_QUIT WM_USER+999

#define CLASS_NAME "ADAGRAPH_CLASS"

#define NO_ERRORS               0
#define WINDOW_ALREADY_OPEN    -1
#define WINDOW_ALREADY_CLOSED  -2
#define CREATE_EVENT_FAILED    -3
#define CREATE_THREAD_FAILED   -4
#define WINDOW_NOT_OPEN        -5
#define INVALID_COLOR_VALUE    -6
#define INVALID_COORDINATE     -7
#define ERROR_COPYING_TITLE    -8
#define ERROR_COPYING_CMDLINE  -9
#define WAIT_FAILED_ERROR     -10
#define SET_TITLE_ERROR       -11
#define FILL_RECT_ERROR       -12
#define INVALIDATE_RECT_ERROR -13
#define UPDATE_WINDOW_ERROR   -14
#define SET_PIXEL_ERROR       -15
#define SELECT_PEN_ERROR      -16
#define MOVE_TO_ERROR         -17
#define LINE_TO_ERROR         -18
#define SELECT_BRUSH_ERROR    -19
#define RECTANGLE_ERROR       -20
#define ELLIPSE_ERROR         -21
#define GET_PIXEL_ERROR       -22
#define FLOOD_FILL_ERROR      -23
#define SET_TEXTCOLOR_ERROR   -24
#define TEXT_OUT_ERROR        -25
#define INVALID_WINDOW_SIZE   -26
#define GET_POSITION_ERROR    -27
#define CLOSE_HANDLE_FAILED   -28
#define THREAD_STATUS_ERROR   -29

#define SIMPLE_BLEEP 0xFFFFFFFF

#define MAX_BITMAPS 32


/**********************************************************************/
/*                              TYPES                                 */
/**********************************************************************/

typedef struct {
   int event;
   int x;
   int y;
} MOUSE_STRUCT;


/**********************************************************************/
/*                        PROCESS GLOBAL DATA                         */
/**********************************************************************/

static int x_size = 0;
static int y_size = 0;

static int x_font = 0;
static int y_font = 0;

static int x_asked = 0;
static int y_asked = 0;

static BOOL active  = FALSE;

static const COLORREF standard_color[MAX_COLORS] = {
   RGB(  0,   0,   0),    /* Black         */
   RGB(  0,   0, 128),    /* Blue          */
   RGB(  0, 128,   0),    /* Green         */
   RGB(  0, 128, 128),    /* Cyan          */
   RGB(128,   0,   0),    /* Red           */
   RGB(128,   0, 128),    /* Magenta       */
   RGB(128, 128,   0),    /* Brown         */
   RGB(172, 172, 172),    /* Light_Gray    */
   RGB( 79,  79,  79),    /* Dark_Gray     */
   RGB(  0,   0, 255),    /* Light_Blue    */
   RGB(  0, 255,   0),    /* Light_Green   */
   RGB(  0, 255, 255),    /* Light_Cyan    */
   RGB(255,   0,   0),    /* Light_Red     */
   RGB(255,   0, 255),    /* Light_Magenta */
   RGB(255, 255,   0),    /* Yellow        */
   RGB(255, 255, 255)     /* White         */
};

static char title[256];

static DWORD  threadID;
static HANDLE hRunning;
static HWND   threadHandle;

static MOUSE_STRUCT mouse = {0, 0, 0};

static HDC     my_dc;
static HWND    my_hwnd;
static RECT    draw_rect, my_rect;
static HBITMAP my_bitmap, old_bitmap;

static HBRUSH   null_brush;
static COLORREF rgb_color[MAX_COLORS];
static HPEN     standard_pen[MAX_COLORS];
static HBRUSH   standard_brush[MAX_COLORS];

static int key_code       = 0;
static BOOL key_stacked   = FALSE;
static BOOL key_available = FALSE;
static int key_type       = NORMAL_KEY;


/**********************************************************************/
/*                       FUNCTION PROTOTYPES                          */
/**********************************************************************/

LONG GraphWin(LPVOID param);
void error_message(int line);
BOOL WINAPI DllMain(HINSTANCE hInst, ULONG reason, LPVOID reserved);
LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);


/**********************************************************************/
/*                        DLL ENTRY POINT                             */
/**********************************************************************/

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG reason, LPVOID reserved)
{
   switch (reason) {

      case DLL_PROCESS_ATTACH:
         x_asked       = 0;
         y_asked       = 0;
         key_code      = 0;
         mouse.event   = 0;
         mouse.x       = 0;
         mouse.y       = 0;
         key_stacked   = FALSE;
         key_available = FALSE;
         key_type      = NORMAL_KEY;
         break;

      case DLL_THREAD_ATTACH:
         break;

      case DLL_THREAD_DETACH:
         break;

      case DLL_PROCESS_DETACH:
         break;
   }

   return TRUE;
}


/**********************************************************************/
/*                        ADA ENTRY POINTS                            */
/**********************************************************************/

/* ------------------------------------------------------------------ */
EXPORT int GetDLLVersion(void)
{
   return DLL_VERSION;
}


/* ------------------------------------------------------------------ */
EXPORT int IsOpen(void)
{
   if (active == TRUE) {
      return 1;
   }
   return 0;
}


/* ------------------------------------------------------------------ */
EXPORT int GetMaxSize(int *x, int *y)
{
   *x = GetSystemMetrics(SM_CXMAXIMIZED) -
        2 * GetSystemMetrics(SM_CXFIXEDFRAME);
   *y = GetSystemMetrics(SM_CYMAXIMIZED) -
        2 * GetSystemMetrics(SM_CYFIXEDFRAME) -
        GetSystemMetrics(SM_CYCAPTION);

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int CreateSizedGraphWindow(int x, int y)
{
   int xmax, ymax;
   int window_size;

   if (active == TRUE) {
      return WINDOW_ALREADY_OPEN;
   }

   (void)GetMaxSize (&xmax, &ymax);

   if ( (x < 0) || (y < 0) || (x > xmax) || (y > ymax)) {
      return INVALID_WINDOW_SIZE;
   }

   window_size = SIZED_WINDOW;

   x_asked = x;
   y_asked = y;

   if (lstrcpy(title, "AdaGraph "VERSION_STRING" window for ") == NULL) {
      return ERROR_COPYING_TITLE;
   }

   if (lstrcat(title, GetCommandLine()) == NULL) {
      return ERROR_COPYING_CMDLINE;
   }

   hRunning = CreateEvent(NULL, FALSE, FALSE, NULL);
   if (hRunning == NULL) {
      return CREATE_EVENT_FAILED;
   }

   threadHandle = CreateThread(NULL,
                               0,
                               (LPTHREAD_START_ROUTINE)GraphWin,
                               (LPVOID)&window_size,
                               0,
                               &threadID);
   if (threadHandle == NULL) {
      return CREATE_THREAD_FAILED;
   }

   if (WaitForSingleObject(hRunning, INFINITE) == WAIT_FAILED) {
      return WAIT_FAILED_ERROR;
   }

   if (CloseHandle(hRunning) == FALSE) {
      return CLOSE_HANDLE_FAILED;
   }

   active  = TRUE;

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int CreateGraphWindow(int size)
{
   int window_size;

   if (active == TRUE) {
      return WINDOW_ALREADY_OPEN;
   }

   if ( (size != DEFAULT_WINDOW) && (size != MAXIMIZED_WINDOW) ) {
      return INVALID_WINDOW_SIZE;
   }

   if (lstrcpy(title, "AdaGraph "VERSION_STRING" window for ") == NULL) {
      return ERROR_COPYING_TITLE;
   }

   if (lstrcat(title, GetCommandLine()) == NULL) {
      return ERROR_COPYING_CMDLINE;
   }

   hRunning = CreateEvent(NULL, FALSE, FALSE, NULL);
   if (hRunning == NULL) {
      return CREATE_EVENT_FAILED;
   }

   window_size = size;

   threadHandle = CreateThread(NULL,
                               0,
                               (LPTHREAD_START_ROUTINE)GraphWin,
                               (LPVOID)&window_size,
                               0,
                               &threadID);
   if (threadHandle == NULL) {
      return CREATE_THREAD_FAILED;
   }

   if (WaitForSingleObject(hRunning, INFINITE) == WAIT_FAILED) {
      return WAIT_FAILED_ERROR;
   }

   if (CloseHandle(hRunning) == FALSE) {
      return CLOSE_HANDLE_FAILED;
   }

   active  = TRUE;

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DestroyGraphWindow(void)
{
   int thread_active;

   if (active == FALSE) {
      return WINDOW_ALREADY_CLOSED;
   }

   (void)SendMessage(my_hwnd, WM_ADAGRAPH_QUIT, 0, 0);

   do {
      if (GetExitCodeThread(threadHandle, &thread_active) == FALSE) {
         return THREAD_STATUS_ERROR;
      }
   } while (thread_active == STILL_ACTIVE);

   if (CloseHandle(threadHandle) == FALSE) {
      return CLOSE_HANDLE_FAILED;
   }

   active  = FALSE;

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int GetWindowWidth(void)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   return x_size;
}


/* ------------------------------------------------------------------ */
EXPORT int GetWindowHeight(void)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   return y_size;
}


/* ------------------------------------------------------------------ */
EXPORT int GetFontWidth(void)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   return x_font;
}


/* ------------------------------------------------------------------ */
EXPORT int GetFontHeight(void)
{
   if (active == FALSE) {
       return WINDOW_NOT_OPEN;
   }

   return y_font;
}


/* ------------------------------------------------------------------ */
EXPORT int ClearWindow(int color_index)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
      return INVALID_COLOR_VALUE;
   }

   if (FillRect(my_dc, &my_rect, standard_brush[color_index]) == FALSE) {
      return FILL_RECT_ERROR;
   }

   if (InvalidateRect(my_hwnd, NULL, TRUE) == FALSE) {
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int SetWindowTitle(char *title)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if (SetWindowText(my_hwnd, title) == FALSE) {
      return SET_TITLE_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int GetColorPixel(int x, int y)
{
   int i;
   COLORREF pixel_color;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      return INVALID_COORDINATE;
   }

   pixel_color = GetPixel(my_dc, x, y);
   if (pixel_color == CLR_INVALID) {
      return GET_PIXEL_ERROR;
   }

   for (i = 0; i < MAX_COLORS; i++) {
      if (rgb_color[i] == pixel_color) {
         return i;
      }
   }

   return INVALID_COLOR_VALUE;
}


/* ------------------------------------------------------------------ */
EXPORT int PutPixel(int x, int y, int color_index)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      return INVALID_COORDINATE;
   }

   if (SetPixelV(my_dc, x, y, rgb_color[color_index]) == FALSE) {
      return SET_PIXEL_ERROR;
   }

   draw_rect.left   = x;
   draw_rect.right  = x + 1;
   draw_rect.top    = y;
   draw_rect.bottom = y + 1;

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DrawLine(int x1, int y1, int x2, int y2, int color_index)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
      return INVALID_COLOR_VALUE;
   }

   if ( (x1 < 0) || (y1 < 0) || (x1 > x_size) || (y1 > y_size) ) {
      return INVALID_COORDINATE;
   }

   if ( (x2 < 0) || (y2 < 0) || (x2 > x_size) || (y2 > y_size) ) {
      return INVALID_COORDINATE;
   }

   if ( (x1 == x2) && (y1 == y2) ) {
      return PutPixel(x1, y1, color_index);
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
      return SELECT_PEN_ERROR;
   }

   if (MoveToEx(my_dc, x1, y1, NULL) == FALSE) {
      return MOVE_TO_ERROR;
   }

   if (LineTo(my_dc, x2, y2) == FALSE) {
      return LINE_TO_ERROR;
   }

   if (SetPixelV(my_dc, x2, y2, rgb_color[color_index]) == FALSE) {
      return SET_PIXEL_ERROR;
   }

   if (x2 >= x1) {
      draw_rect.left  = x1;
      draw_rect.right = x2 + 1;
   }
   else {
      draw_rect.left  = x2;
      draw_rect.right = x1 + 1;
   }

   if (y2 >= y1) {
      draw_rect.top    = y1;
      draw_rect.bottom = y2 + 1;
   }
   else {
      draw_rect.top    = y2;
      draw_rect.bottom = y1 + 1;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DrawBox(int x1, int y1, int x2, int y2, int color_index, int filled)
{
   int d_x1, d_x2, d_y1, d_y2;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
      return INVALID_COLOR_VALUE;
   }

   if ( (x1 < 0) || (y1 < 0) || (x1 > x_size) || (y1 > y_size) ) {
      return INVALID_COORDINATE;
   }

   if ( (x2 < 0) || (y2 < 0) || (x2 > x_size) || (y2 > y_size) ) {
      return INVALID_COORDINATE;
   }

   if ((x1 == x2) && (y1 == y2)) {
      return PutPixel(x1, y1, color_index);
   }

   if ((x1 == x2) || (y1 == y2)) {
      return DrawLine(x1, y1, x2, y2, color_index);
   }

   if (x2 > x1) {
      d_x1 = x1;
      d_x2 = x2;
   }
   else {
      d_x1 = x2;
      d_x2 = x1;
   }

   if (y2 > y1) {
        d_y1 = y1;
        d_y2 = y2;
   }
   else {
      d_y1 = y2;
      d_y2 = y1;
   }

   d_x2++;
   d_y2++;

   if (filled == TRUE) {
      if (SelectObject(my_dc, standard_brush[color_index]) == NULL) {
         return SELECT_BRUSH_ERROR;
      }
   }
   else {
      if (SelectObject(my_dc, null_brush) == NULL) {
         return SELECT_BRUSH_ERROR;
       }
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
      return SELECT_PEN_ERROR;
   }

   if (Rectangle(my_dc, d_x1, d_y1, d_x2, d_y2) == FALSE) {
      return RECTANGLE_ERROR;
   }

   draw_rect.left   = d_x1;
   draw_rect.right  = d_x2;
   draw_rect.top    = d_y1;
   draw_rect.bottom = d_y2;

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DrawCircle(int x, int y, int radius, int color_index, int filled)
{
   int d_x1, d_x2, d_y1, d_y2;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      return INVALID_COORDINATE;
   }

   if (radius == 0) {
      return PutPixel(x, y, color_index);
   }

   if ( ((x - radius) < 0) || ((y - radius) < 0) ||
        ((x + radius) > x_size) || ((y + radius) > y_size) ) {
      return INVALID_COORDINATE;
   }

   draw_rect.left   = d_x1 = x - radius;
   draw_rect.top    = d_y1 = y - radius;
   draw_rect.right  = d_x2 = x + radius + 1;
   draw_rect.bottom = d_y2 = y + radius + 1;

   if (filled == TRUE) {
      if (SelectObject(my_dc, standard_brush[color_index]) == NULL) {
         return SELECT_BRUSH_ERROR;
      }
   }
   else {
      if (SelectObject(my_dc, null_brush) == NULL) {
         return SELECT_BRUSH_ERROR;
       }
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
      return SELECT_PEN_ERROR;
   }

   if (Ellipse(my_dc, d_x1, d_y1, d_x2, d_y2) == FALSE) {
      return ELLIPSE_ERROR;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DrawEllipse(int x1, int y1, int x2, int y2, int color_index, int filled)
{
   int d_x1, d_x2, d_y1, d_y2;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
      return INVALID_COLOR_VALUE;
   }

   if ( (x1 < 0) || (y1 < 0) || (x1 > x_size) || (y1 > y_size) ) {
      return INVALID_COORDINATE;
   }

   if ( (x2 < 0) || (y2 < 0) || (x2 > x_size) || (y2 > y_size) ) {
      return INVALID_COORDINATE;
   }

   if ((x1 == x2) && (y1 == y2)) {
      return PutPixel(x1, y1, color_index);
   }

   if ((x1 == x2) || (y1 == y2)) {
      return DrawLine(x1, x2, y1, y2, color_index);
   }

   if (x2 > x1) {
      d_x1 = x1;
      d_x2 = x2;
   }
   else {
      d_x1 = x2;
      d_x2 = x1;
   }

   if (y2 > y1) {
      d_y1 = y1;
      d_y2 = y2;
   }
   else {
      d_y1 = y2;
      d_y2 = y1;
   }

   draw_rect.left   = d_x1;
   draw_rect.right  = d_x2 + 1;
   draw_rect.top    = d_y1;
   draw_rect.bottom = d_y2 + 1;

   if (filled == TRUE) {
      if (SelectObject(my_dc, standard_brush[color_index]) == NULL) {
         return SELECT_BRUSH_ERROR;
      }
   }
   else {
      if (SelectObject(my_dc, null_brush) == NULL) {
         return SELECT_BRUSH_ERROR;
      }
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
      return SELECT_PEN_ERROR;
   }

   if (Ellipse(my_dc, d_x1, d_y1, d_x2, d_y2) == FALSE) {
      return ELLIPSE_ERROR;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int FillFlood(int x, int y, int color_index)
{
   COLORREF color;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      return INVALID_COORDINATE;
   }

   color = GetPixel(my_dc, x, y);
   if (color == CLR_INVALID) {
      return GET_PIXEL_ERROR;
   }

   if (SelectObject(my_dc, standard_brush[color_index]) == NULL) {
      return SELECT_BRUSH_ERROR;
   }

   if (ExtFloodFill(my_dc, x, y, color, FLOODFILLSURFACE) == FALSE) {
      return FLOOD_FILL_ERROR;
   }

   if (InvalidateRect(my_hwnd, NULL, FALSE) == FALSE) {
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DisplayText(int x, int y, char *text, int color_index)
{
   int str_length, x_end, y_end;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   str_length = lstrlen(text);

   if (str_length == 0) {
      return NO_ERRORS;
   }

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      return INVALID_COORDINATE;
   }

   x_end = x + str_length * x_font - 1;

   if ( x_end > x_size) {
      return INVALID_COORDINATE;
   }

   y_end = y + y_font - 1;

   if ( y_end > y_size) {
      return INVALID_COORDINATE;
   }

   if (SetTextColor(my_dc, rgb_color[color_index]) == CLR_INVALID) {
      return SET_TEXTCOLOR_ERROR;
   }

   if (TextOut(my_dc, x, y, text, str_length) == FALSE) {
      return TEXT_OUT_ERROR;
   }

   draw_rect.left   = x;
   draw_rect.right  = x_end + 1;
   draw_rect.top    = y;
   draw_rect.bottom = y_end + 1;

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int WhereX(void)
{
   POINT my_point;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if (GetCurrentPositionEx(my_dc, &my_point) == FALSE) {
      return GET_POSITION_ERROR;
   }

   return (int)my_point.x;
}


/* ------------------------------------------------------------------ */
EXPORT int WhereY(void)
{
   POINT my_point;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if (GetCurrentPositionEx(my_dc, &my_point) == FALSE) {
      return GET_POSITION_ERROR;
   }

   return (int)my_point.y;
}


/* ------------------------------------------------------------------ */
EXPORT int GotoXY(int x, int y)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if (MoveToEx(my_dc, x, y, NULL) == FALSE) {
      return MOVE_TO_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int DrawTo(int x, int y, int color_index)
{
   POINT my_point;
   int curr_x, curr_y;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if (GetCurrentPositionEx(my_dc, &my_point) == FALSE) {
      return GET_POSITION_ERROR;
   }
   curr_x = (int)my_point.x;
   curr_y = (int)my_point.y;

   if ( (color_index < 0) || (color_index >= MAX_COLORS) ) {
      return INVALID_COLOR_VALUE;
   }

   if ( (x < 0) || (y < 0) || (x > x_size) || (y > y_size) ) {
      return INVALID_COORDINATE;
   }

   if ( (x == curr_x) && (y == curr_y) ) {
      return PutPixel(x, y, color_index);
   }

   if (SelectObject(my_dc, standard_pen[color_index]) == NULL) {
      return SELECT_PEN_ERROR;
   }

   if (LineTo(my_dc, x, y) == FALSE) {
      return LINE_TO_ERROR;
   }

   if (SetPixelV(my_dc, x, y, rgb_color[color_index]) == FALSE) {
      return SET_PIXEL_ERROR;
   }

   if (x >= curr_x) {
      draw_rect.left  = curr_x;
      draw_rect.right = x + 1;
   }
   else {
      draw_rect.left  = x;
      draw_rect.right = curr_x + 1;
   }

   if (y >= curr_y) {
      draw_rect.top    = curr_y;
      draw_rect.bottom = y + 1;
   }
   else {
      draw_rect.top    = y;
      draw_rect.bottom = curr_y + 1;
   }

   if (InvalidateRect(my_hwnd, &draw_rect, FALSE) == FALSE) {
      return INVALIDATE_RECT_ERROR;
   }

   if (UpdateWindow(my_hwnd) == FALSE) {
      return UPDATE_WINDOW_ERROR;
   }

   return NO_ERRORS;
}


/* ------------------------------------------------------------------ */
EXPORT int KeyHit(void)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   return key_available;
}


/* ------------------------------------------------------------------ */
EXPORT int GetKey(void)
{
   int result;

   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if (key_stacked == TRUE) {
      result = key_code;
      key_stacked = FALSE;
      return result;
   }

   while (key_available == FALSE) {
      /* do_nothing */
   }

   if (key_type == NORMAL_KEY) {
      result = key_code;
   }
   else {
      result = 0;
      key_stacked = TRUE;
   }

   key_available = FALSE;

   return result;
}


/* ------------------------------------------------------------------ */
EXPORT int MouseEvent(void)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   if (mouse.event != NONE) {
      return 1;
   }
   else {
      return 0;
   }
}


/* ------------------------------------------------------------------ */
EXPORT int GetMouse(MOUSE_STRUCT *mouse_event)
{
   if (active == FALSE) {
      return WINDOW_NOT_OPEN;
   }

   while (mouse.event == NONE) {
      /* do nothing */
   }

   *mouse_event = mouse;
   mouse.event = mouse.x = mouse.y = 0;

   return NO_ERRORS;
}


/**********************************************************************/
/*                    GRAPHICAL WINDOW THREAD                         */
/**********************************************************************/

LONG GraphWin(LPVOID size)
{
   HDC hDC;
   MSG msg;
   TEXTMETRIC tm;
   WNDCLASS wndclass;
   int i, x1, y1, x2, y2;

   wndclass.style         = CS_BYTEALIGNCLIENT | CS_NOCLOSE;
   wndclass.lpfnWndProc   = WndProc;
   wndclass.cbClsExtra    = 0;
   wndclass.cbWndExtra    = 0;
   wndclass.hInstance     = NULL;
   wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
   wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
   wndclass.hbrBackground = GetStockObject(BLACK_BRUSH);
   wndclass.lpszMenuName  = NULL;
   wndclass.lpszClassName = CLASS_NAME;

   (void) RegisterClass (&wndclass);

   switch (*((int *)size)) {

      case DEFAULT_WINDOW:
         x1 = y1 = x2 = y2 = CW_USEDEFAULT;
         break;

      case MAXIMIZED_WINDOW:
         x1 = 0;
         y1 = 0;
         x2 = GetSystemMetrics(SM_CXMAXIMIZED) -
              2 * GetSystemMetrics(SM_CXFIXEDFRAME);
         y2 = GetSystemMetrics(SM_CYMAXIMIZED) -
              2 * GetSystemMetrics(SM_CYFIXEDFRAME);
         break;

      case SIZED_WINDOW:
         x1 = 0;
         x2 = 0;
         x2 = x_asked + 2 * GetSystemMetrics(SM_CXFIXEDFRAME);
         y2 = y_asked + 2 * GetSystemMetrics(SM_CYFIXEDFRAME) +
              GetSystemMetrics(SM_CYCAPTION);
         break;

   }

   my_hwnd = CreateWindow(CLASS_NAME,
                          title,
                          WS_OVERLAPPED,
                          x1,
                          y1,
                          x2,
                          y2,
                          NULL,
                          NULL,
                          NULL,
                          NULL);
   if (my_hwnd == NULL) { error_message(__LINE__); }

   if (GetClientRect(my_hwnd, &my_rect) == FALSE) { error_message(__LINE__); }
   x_size = (int)my_rect.right - 1;
   y_size = (int)my_rect.bottom - 1;

   hDC = GetDC(my_hwnd);
   if (hDC == NULL) { error_message(__LINE__); }

   my_dc = CreateCompatibleDC(hDC);
   if (my_dc == NULL) { error_message(__LINE__); }

   my_bitmap = CreateCompatibleBitmap(hDC, x_size + 1, y_size + 1);
   if (my_bitmap == NULL) { error_message(__LINE__); }

   old_bitmap = SelectObject(my_dc, my_bitmap);
   if (old_bitmap == NULL) { error_message(__LINE__); }

   if (ReleaseDC(my_hwnd, hDC) == 0) { error_message(__LINE__); }

   for (i = 0; i < MAX_COLORS; i++) {
      rgb_color[i] = GetNearestColor(my_dc, standard_color[i]);
      if (rgb_color[i] == CLR_INVALID) { error_message(__LINE__); }
      standard_brush[i] = CreateSolidBrush(rgb_color[i]);
      if (standard_brush[i] == NULL) { error_message(__LINE__); }
      standard_pen[i] = CreatePen(PS_SOLID, 0, rgb_color[i]);
      if (standard_pen[i] == NULL) { error_message(__LINE__); }
   }

   if (SelectObject (my_dc, GetStockObject(ANSI_FIXED_FONT)) == NULL) {
      error_message(__LINE__);
   }

   if (GetTextMetrics(my_dc, &tm) == FALSE) { error_message(__LINE__); }
   x_font = tm.tmMaxCharWidth;
   y_font = tm.tmHeight;

   if (SetBkMode(my_dc, TRANSPARENT) == 0) { error_message(__LINE__); }

   null_brush = GetStockObject(NULL_BRUSH);
   if (null_brush == NULL) { error_message(__LINE__); }

   if (FillRect(my_dc, &my_rect, standard_brush[0]) == FALSE) {
      error_message(__LINE__);
   }

   if (GdiSetBatchLimit(1) == 0) { error_message(__LINE__); }

   if (SetEvent(hRunning) == FALSE) { error_message(__LINE__); }

   (void)ShowWindow(my_hwnd, SW_SHOWNORMAL);
   if (UpdateWindow(my_hwnd) == FALSE) { error_message(__LINE__); }
   (void)SetForegroundWindow(my_hwnd); /* always fails but is necessary */

   while (GetMessage(&msg, NULL, 0, 0)) {
      (void)TranslateMessage(&msg);
      (void)DispatchMessage(&msg);
   }

   if (DeleteObject(SelectObject(my_dc, old_bitmap)) == FALSE) {
      error_message(__LINE__);
   }

   if (DeleteDC(my_dc) == FALSE) { error_message(__LINE__); }

   for (i = 0; i < MAX_COLORS; i++) {
      if (DeleteObject(standard_pen[i]) == FALSE) { error_message(__LINE__); }
      if (DeleteObject(standard_brush[i]) == FALSE) { error_message(__LINE__); }
   }

   return msg.wParam;
}


/**********************************************************************/
/*                  GRAPHICAL WINDOW PROCEDURE                        */
/**********************************************************************/

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   PAINTSTRUCT ps;

   switch (uMsg) {

      case WM_ADAGRAPH_QUIT:
         (void)SendMessage(hwnd, WM_DESTROY, 0, 0);
         return 0;

      case WM_DESTROY:
         (void)PostQuitMessage(NO_ERRORS);
         return 0;

      case WM_PAINT:
         if (BeginPaint(hwnd, &ps) == NULL) { error_message(__LINE__); };

         if (BitBlt(ps.hdc,
                    ps.rcPaint.left,
                    ps.rcPaint.top,
                    ps.rcPaint.right + 1,
                    ps.rcPaint.bottom + 1,
                    my_dc,
                    ps.rcPaint.left,
                    ps.rcPaint.top,
                    SRCCOPY) == FALSE) {
            error_message(__LINE__);
         }

         (void)EndPaint(hwnd, &ps);
         return 0;

      case WM_KEYDOWN:
         if (key_available == FALSE) {
            switch (wParam) {
               case VK_PRIOR: /* page-up   */
               case VK_NEXT:  /* page-down */
               case VK_END:
               case VK_HOME:
               case VK_LEFT:
               case VK_UP:
               case VK_RIGHT:
               case VK_DOWN:
               case VK_INSERT:
               case VK_DELETE:
                  key_code      = (int)wParam;
                  key_available = TRUE;
                  key_type      = VIRTUAL_KEY;
                  return 0;
            }
            return 0;
         }
         if (MessageBeep (SIMPLE_BLEEP) == FALSE) { error_message(__LINE__); }
         return 1;

      case WM_CHAR:
         if (key_available == FALSE) {
            key_available = TRUE;
            key_type      = NORMAL_KEY;
            key_code      = (int)wParam;
            return 0;
         }
         if (MessageBeep (SIMPLE_BLEEP) == FALSE) { error_message(__LINE__); }
         return 0;

      case WM_LBUTTONUP:
         mouse.event = LEFT_UP;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;

      case WM_LBUTTONDOWN:
         mouse.event = LEFT_DOWN;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;

      case WM_RBUTTONUP:
         mouse.event = RIGHT_UP;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;

      case WM_RBUTTONDOWN:
         mouse.event = RIGHT_DOWN;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;

      case WM_MOUSEMOVE:
         mouse.event = MOVE;
         mouse.x     = LOWORD(lParam);
         mouse.y     = HIWORD(lParam);
         return 0;
   }

   return DefWindowProc(hwnd, uMsg, wParam, lParam);
}


/**********************************************************************/
/*                       GRAPHICS ERROR MESSAGE                       */
/**********************************************************************/

void error_message(int line)
{
   LPVOID msg;
   char error_msg[256];

   (void)FormatMessage(
      FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
      NULL,
      GetLastError(),
      MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
      (LPTSTR) &msg,
      0,
      NULL
   );

   (void)wsprintf(error_msg, "ADAGRAPH.C at line %d\n%s", line, msg);

   (void)MessageBeep (SIMPLE_BLEEP);
   (void)MessageBox(NULL,
                    error_msg,
                    ERROR_TITLE,
                    MB_OK |
                    MB_ICONINFORMATION |
                    MB_SYSTEMMODAL |
                    MB_TOPMOST |
                    MB_SETFOREGROUND);

   (void)LocalFree(msg);
}
