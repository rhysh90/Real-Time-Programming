RawWrite for Windows
====================
95, 98, ME, NT, 2K, XP

Under 95, 98 & ME you need diskio.dll.  It must be in the same directory as rawwritewin.exe

rawwritewin was supplied by John Newbigin
http://uranus.it.swin.edu.au/~jn/linux/rawwritewin-0.7.zip
 under GNU licence -- see rawwritewin_COPYING.txt